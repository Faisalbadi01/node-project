const mongoose=require('mongoose');
const { emit } = require('process')
const main=require("../model/schema")
const table=require('../model/mainschema')
const { all } = require('../routes/routes')
const fs=require('fs')


const session=require('express-session');

const passport=require('passport')









const index=(req,res)=>{

    res.render("sign")
}


const login=(req,res)=>{

    res.render( "login" )

}
const home=(req,res)=>{

    res.render( "home" )

}


const  sign=(req,res)=>{


    main.create(req.body)
    res.redirect('login')
    
}
 const lg=('/log',passport.authenticate('local'),(req,res)=>{

    res.render('index');


 })

 const add=(req,res)=>{


    res.render( 'add' );

 }

 const insert=(req,res)=>{


    table.create({

        name: req.body.name,
        number:req.body.number,
        gender:req.body.gender,
        email:req.body.email,
        pin:req.body.pin,


        img:req.file.path
    }).then(()=>{

        console.log("successfully insert");
        return res.redirect('/add')

    })

 }



 const view=(req,res)=>{


    table.find({}).then((alldata)=>{

        res.render("view",{

            data :alldata
        })


    })
  
 }

 
 const alldelet=(req,res)=>{

    let id=req.query.id;

    table.findById(id).then((data)=>{

        fs.unlinkSync(data.img);

    })

   table.findByIdAndDelete(id).then(()=>{

        return res.redirect('/view');
    })
}



const edit=(req,res)=>{

    let id=req.query.id;

    table.findById(id).then((alldata)=>{

        res.render('edit',{
            edit:alldata
        })
    })
}


const update=(req,res)=>{

let id=req.body.id;


if (req.file) {
        
    var alldata={
            name:req.body.name,
         number:req.body.number,
        gender:req.body.gender,
        email:req.body.email,
        pin:req.body.pin,
           img:req.file.path
    }
    
}

else{
    var alldata={
        
        name:req.body.name,
        number:req.body.number,
       gender:req.body.gender,
       email:req.body.email,
       pin:req.body.pin,
      
}

}
table.findByIdAndUpdate(id,alldata).then(()=>{


    console.log("succes update");
    res.redirect('/view');
 
})



}

    module.exports={


        index,
        login,
        home,
        sign,
        lg,
        add,
        insert,
        view,
        alldelet,
        edit,
        update,
    }