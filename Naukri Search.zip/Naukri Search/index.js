const express = require('express');
const port = 5957;
const app = express();
app.use(express.urlencoded());
const path = require('path');

const session = require('express-session');
app.use(session({ secret: "private-key" }));
const passport = require('passport')

const localauth = require('./middleware/localauth');
app.use('/uploads', express.static(__dirname + '/uploads'));

app.use(express.static(path.join(__dirname, 'public')));


localauth(passport);

app.use(passport.initialize());
app.use(passport.session());



const database = require('./config/database');
const main = require('./model/schema');
const table = require('./model/mainschema')



// app.use('/uploads',express.static(__dirname + '/uploads')); 
const fs = require('fs')



app.set("view engine", "ejs");


app.use('/', require('./routes/routes'));


app.listen(port, () => {

    console.log(`Server is running on ${port}`);

})