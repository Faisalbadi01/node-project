const mongoose=require('mongoose');

mongoose.connect('mongodb://127.0.0.1/project1');

var db = mongoose.connection;

db.on('connected',()=>{

    console.log("connected succesfully");
})


module.exports=db;