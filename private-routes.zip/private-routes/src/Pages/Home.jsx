import React from 'react'

import "./Login.modules.css"


import "./flex-slider.css"
import "./fontawesome.css"
import "./owl.css"

function Home() {
  return (
    <div>

     



    </div>


  )
}

export default Home