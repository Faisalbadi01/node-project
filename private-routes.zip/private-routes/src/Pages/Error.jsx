

function Error() {
  return (
    <div>404 Error Not Found</div>
  )
}

export default Error