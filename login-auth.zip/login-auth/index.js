const express = require('express');

const port = 9898;

const app = express();

const path = require('path');

app.use(express.static(path.join(__dirname, 'public')));

app.use('/uploads', express.static(__dirname + '/uploads'));

app.use(express.urlencoded())
const multer = require('multer');
const database = require('./config/database');

const table = require('./model/schema');
const data = require('./model/adminschema')



///caterory///

const main = require('./model/caterory');

const sub = require('./model/subcaterory');
const extra = require('./model/extracaterory')



const storage = multer.diskStorage({



    destination: (req, res, cb) => {

        cb(null, 'uploads/')
    },
    filename: (req, file, cb) => {

        cb(null, file.originalname)
    }

})

const upload = multer({ storage: storage }).single('image')








const nodemailer = require('nodemailer');

const otp = Math.floor(Math.random() * 10000);

app.set("view engine", "ejs")




const session = require('express-session');

app.use(session({ secret: "private-key" }));

const flash = require('connect-flash');
const { receiveMessageOnPort } = require('worker_threads');

app.use(flash());




















///send mail////////



const sendMail = async (req, res) => {

    const transporter = nodemailer.createTransport({

        service: 'gmail',
        auth: {

            user: "faisalbadi57@gmail.com",
            pass: "ymlsdfyrzbowplto",


        },
    });

    const info = await transporter.sendMail({

        from: "faisalbadi57@gmail.com",
        to: req.body.email,
        subject: "opt",
        html: `${otp}`

    })
    res.redirect('login')

}









//verfiy////





const verifiy = async (req, res) => {

    let token = req.body.otp;


    if (token == otp) {

        let email = req.body.email;


        let user = await table.findOne({ email: email });

        let id = user.id;

        let password = req.body.newpassword;

        await table.findByIdAndUpdate(id, { password: password })


        res.redirect("log")

    }
    else {

        res.redirect("error")
    }
}










//login/////




const logup = async (req, res) => {

    let data = req.body;

    let exituser = await table.findOne({ email: data.email });

    if (!exituser) {

        res.send("this is wrong user")
    }
    if (exituser.password != data.password) {
        res.send("this is wrong password")
    }
    else {
        res.redirect("/home")
    }
}







app.get("/", (req, res) => {


    res.render("resgistar")


})

app.get("/login", (req, res) => {

    res.render("login")


})

app.get("/home", (req, res) => {

    res.render('home')

})


app.get("/userlogin", (req, res) => {

    res.render("userlogin")


})

app.post("/userlogin", (req, res) => {


    let add = "faisalbadi57@gmail.com";
    let pass = 121;


    let admin = req.body.ad;
    let password = req.body.ps;


    if (add == admin && pass == password) {

        res.redirect('/index')
    }
    else {
        res.send("wrong user")
    }



});

app.get("/index", (req, res) => {

    res.render('')
})

app.get("/error", (req, res) => {

    res.render('error')

})
app.get("/log", (req, res) => {

    res.render('log', { info: req.flash("msg") })

})

app.post("/log", logup, (req, res) => {





    req.flash("msg", "password change Successfuly")
});









app.post("/otp", sendMail);

app.post("/insert", (req, res) => {


    let data = req.body;

    table.create(data)

    res.redirect("/log")

})

app.get("/forgot", (req, res) => {

    res.render("forgot");



})

app.post("/update", verifiy);















//carerory///



app.get('/maincaterory', (req, res) => {

    main.find({}).then((alldata) => {

        res.render('cateroryform', {


            rec: alldata
        })

    })
})

app.get('/extra', (req, res) => {

    sub.find({}).populate('mainid').then((alldata) => {

        res.render('extra', {


            rec: alldata
        })

    })





})



app.post('/maincaterory', (req, res) => {


    main.create({


        maincaterory: req.body.maincaterory
    })

    res.redirect('back')
})




app.post('/subcaterory', (req, res) => {


    sub.create({

        mainid: req.body.mainid,
        subcaterory: req.body.subcaterory


    })

    res.redirect('extra')

})

app.post('/extracaterory', upload, (req, res) => {










    extra.create({


        mainid: req.body.mainid,
        subid: req.body.subid,
        extracaterory: req.body.extracaterory,

        image: req.file.path

    }).then(() => {


        res.redirect('back')

    })

})



///views///


app.get("/computer", (req, res) => {



    extra.find({}).populate({
        path: 'subid',
        populate: {
            path: 'mainid'
        }
    }).then((data) => {
        res.render("computer", {
            record: data
        })
    })



})


app.get("/mobile", (req, res) => {

    res.render('mobile')

})


app.get("/fasion", (req, res) => {

    res.render('fasion')

})


app.get('/delete', (req, res) => {


    let id = req.query.id;

    extra.findByIdAndDelete(id).then(() => {

        res.redirect('/computer')
    })
})



app.listen(port, () => {

    console.log("server started at:-" + port);


})