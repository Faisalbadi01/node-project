const mongoose=require('mongoose');

mongoose.connect("mongodb://127.0.0.1/project-5");


var db = mongoose.connection;

db.on('connected',()=>{

    console.log("databaase connected");


})


module.exports=db;

