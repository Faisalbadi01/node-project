const mongoose=require( 'mongoose');


const  schema = mongoose.Schema({
   maincaterory:{

        type:String,
        required:true
    },



})

const caterory=mongoose.model('caterory',schema);

module.exports=caterory;