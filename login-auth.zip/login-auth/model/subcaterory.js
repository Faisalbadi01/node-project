const mongoose=require('mongoose');

const schema=mongoose.Schema({

    mainid:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"caterory"
    },

   subcaterory:{
        type:String,
        required:true
    }

})

const sub=mongoose.model("sub",schema);

module.exports=sub;