const mongoose=require('mongoose');

const schema=mongoose.Schema({

    mainid:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"caterory"
    },
    subid:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"sub"
    },

    extracaterory:{
        type:String,
        required:true
    },
    image:{
        type:String,
        required:true
    }

})

const extra=mongoose.model("extra",schema);

module.exports=extra;