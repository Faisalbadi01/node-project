const mongoose=require('mongoose');

const schema=mongoose.Schema({

    userName:{

        type:String,
        required:true

    },
    password :{

        type:String,
        required:true

    },
    name:{

        type:String,
        required:true

    },
    surname:{

        type:String,
        required:true

    },
    email:{

        type:String,
        required:true

    },
    address:{

        type:String,
        required:true

    },
    gender:{

        type: String,
        required:true

    },
    acceptTerms:{

        type:String,
        required:true

    },


})

const data=mongoose.model('data',schema);


module.exports=data; 