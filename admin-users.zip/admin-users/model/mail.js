const mongoose=require('mongoose');

const mailSchema=mongoose.Schema({
     
          email:{
            type:String,
            require:true
          },
    
})

const mail=mongoose.model('mail',mailSchema);
module.exports=mail;