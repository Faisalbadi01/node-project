const express = require('express')
const port = 9959;
const app = express();
const database = require('./config/database');
const path = require('path');
const session = require('express-session');
app.use(express.urlencoded());


const caterory = require('./model/adminCaterory');

const subcaterory = require('./model/adminSubCaterory');

const extra = require('./model/adminExtraCaterory');

const user = require('./model/user')


app.use(session({ secret: "private-key" }));
const passport = require('passport');

const localauthh = require('./middleware/localauth');



localauthh(passport);

app.use(express.static(path.join(__dirname, "public")));
app.use('/uploads', express.static(__dirname + '/uploads'));



app.use(passport.initialize());
app.use(passport.session());













app.set("view engine", 'ejs');





app.use(require('./routes/route'));


app.listen(port, () => {

    console.log("server started at :-" + port);
})