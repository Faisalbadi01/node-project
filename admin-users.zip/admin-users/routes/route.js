const express=require('express');

const indexcontroller=require('../controller/indexController')

const route=express.Router();

const database=require('../config/database');
const sig=require('../model/loginschema');
const passport = require('passport');

const localStratagy=require('passport-local').Strategy;

const multer=require('multer');


const nodemailer=require('nodemailer')


const storage=multer.diskStorage({


    destination:(req,res,cb)=>{

        cb(null,'uploads/')
    },
    filename:(req,file,cb)=>{


        cb(null,file.originalname)
    }
})


const upload=multer({storage:storage}).single('image');






const storage1=multer.diskStorage({


    destination:(req,res,cb)=>{

        cb(null,'uploads/')
    },
    filename:(req,file,cb)=>{


        cb(null,file.originalname)
    }
})


const upload1=multer({storage:storage1}).single('image1');





const  sendMail=async(req,res)=>{

    const transporter=nodemailer.createTransport({
    
        service: 'gmail',
         auth:{
    
            user:"faisalbadi57@gmail.com",
            pass:"ymlsdfyrzbowplto",
    
    
         },
    });
    
    const info=await transporter.sendMail({
    
        from:"faisalbadi57@gmail.com",
        to:req.body.email,
        subject:"message",
        html:"<b>Im Owner Of The Company </b> <br> <b>I Like Your Resume WodYou like to come for Interview </b>"
    
    })
    
    }






route.get('/',indexcontroller.home);

route.get('/usersign',indexcontroller.usersign);

route.get('/userlogin',indexcontroller.userlogin);

route.get('/adminlogin',indexcontroller.adminlogin);

route.get('/main',indexcontroller.main);

route.post('/signup',indexcontroller.insert);

route.post('/login',passport.authenticate('local'),indexcontroller.login);


route.post('/adminlog',indexcontroller.adminlog)

route.get('/index',indexcontroller.index)


//admin ejs route//

route.get('/adform',indexcontroller.adform)

route.get('/adsubform',indexcontroller.adsubform)

route.get('/adtable',indexcontroller.adtable)


//user ejs route//


route.get('/about',indexcontroller.about)

route.get('/jobl',indexcontroller.jobl)

route.get('/jobd',indexcontroller.jobd)

route.get('/cate',indexcontroller.cate)

route.get('/cont',indexcontroller.cont)


//admin route//


route.post('/adcaterory',indexcontroller.adminCaterory);

route.post('/subcaterory',indexcontroller.adminSubCaterory);

route.post('/extra',upload,indexcontroller.adminExtraCaterory);


route.get('/delete',indexcontroller.delet)


//user//

route.post('/userinsert',upload1,indexcontroller.userins)

route.get('/ustable',indexcontroller.ustable)


route.get('/delete1',indexcontroller.usdelt);


route.get('/edit',indexcontroller.message)

route.post('/send',sendMail,indexcontroller.mail)

module.exports=route;