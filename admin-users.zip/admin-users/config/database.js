const mongoose=require('mongoose');

mongoose.connect('mongodb://127.0.0.1/final-project');

const db=mongoose.connection;

db.on('connected',()=>{
    console.log("Databased Connected successfully...")
})

module.exports=db;