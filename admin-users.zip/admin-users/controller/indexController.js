
const caterory = require("../model/adminCaterory");
const extra = require("../model/adminExtraCaterory");
const sub = require("../model/adminSubCaterory");
const table = require("../model/loginschema");
const user = require("../model/user");
const mails=require('../model/mail');
const { all } = require("../routes/route");



const home=(req,res)=>{


    res.render('home')
};



const usersign=(req,res)=>{

    res.render('usersign')

};

const userlogin=(req,res)=>{

    res.render('userlogin')

};

const adminlogin=(req,res)=>{

    res.render('adminlogin')

};



const main=(req,res)=>{



    extra.find({}).populate({
        path:'subid',
        populate:{
            path:'mainid'
        }
    }).then((data)=>{
        res.render( "main",{
            record:data
        })
    })

   

};


const insert=(req,res)=>{

    


    table.create(req.body);

 res.redirect('userlogin')
}


const login=(req,res)=>{

    res.redirect('/main')

}

const adminlog=(req,res)=>{

    let add="faisalbadi57@gmail.com";
    let pass=121;


let admin=req.body.ad;
let password=req.body.ps;


if (add==admin && pass==password) {

    res.redirect('/index')
}
else{
    res.send("wrong user")
}
}

const index=(req,res)=>{

    res.render('index')
}



//admin ejs route//


const adform=(req,res)=>{


    caterory.find({}).then((data)=>{

        res.render('adminform',{
            rec:data
        })

    })

 

};


const adsubform=(req,res)=>{


    sub.find({}).populate('mainid').then((alldata)=>{

        res.render('adsubform',{


            rec:alldata
        })

    })


  

};

const adtable=(req,res)=>{
    
    extra.find({}).populate({
        path:'subid',
        populate:{
            path:'mainid'
        }
    }).then((data)=>{
        res.render( "adtable",{
            record:data
        })
    })


};



//user get route//

const about=(req,res)=>{

    res.render('about')

};


const jobl=(req,res)=>{


    extra.find({}).populate({
        path:'subid',
        populate:{
            path:'mainid'
        }
    }).then((data)=>{
        res.render( "jobl",{
            record:data
        })
    })




};


const jobd=(req,res)=>{

    res.render('jobd')

};

const cate=(req,res)=>{

    res.render('cate')

};

const cont=(req,res)=>{

    res.render('cont')

};



//admin curd///


const adminCaterory=(req,res)=>{


    caterory.create(req.body);

    res.redirect('back')

}


const  adminSubCaterory=(req,res)=>{

sub.create(req.body);

    res.redirect('/adsubform')

}

const adminExtraCaterory=(req,res)=>{

    extra.create({
      mainid:req.body.mainid,
      subid:req.body.subid,
      extracaterory:req.body.extracaterory,
        image:req.file.path,
        city:req.body.city

    }).then(()=>{

        console.log("successfully insert");
        return res.redirect('back')

    })
}



const delet=(req,res)=>{

let id=req.query.id;

    extra.findByIdAndDelete(id).then(()=>{
        res.redirect('back')
    })

}







//user curd//


const userins=(req,res)=>{


    user.create({
        name:req.body.name,
        email:req.body.email,
       mobile:req.body.mobile,
          image1:req.file.path,
    })



res.redirect('main')

}

const ustable=(req,res)=>{


    user.find({}).then((alldata)=>{

        res.render('ustable',{

            red:alldata
        })

    })

}


const usdelt=(req,res)=>{

let id=req.query.id;

    user.findByIdAndDelete(id).then(()=>{

        res.redirect('back')
    })

}


const message=(req,res)=>{

    let id=req.query.id;

    user.findById(id).then((da)=>{
res.render('mail',{
    val:da
})

    })

}

const  mail=(req,res)=>{

   mails.create({

        email:req.body.email
    })
    res.redirect('/ustable')

}

module.exports={
    home,
    userlogin,
    usersign,
    adminlogin,
    main,
    insert,
    login,
    adminlog,
    index,
    adform,
    adsubform,
    adtable,
    about,
    jobl,
    jobd,
    cate,
    cont,
    adminCaterory,
    adminSubCaterory,
    adminExtraCaterory,
    delet,
    userins,
    ustable,
    usdelt,
    message,
    mail,

}


